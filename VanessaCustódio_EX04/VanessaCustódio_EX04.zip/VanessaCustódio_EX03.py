n = int(input('Tabuada de :'))
x = 1
while x <=10:
    print(f"{x} X {n} = {x*n}")
    x += 1
