x = 3
contador = 1
while contador <= 10:
    print(x)
    x = x + 3
    contador +=1