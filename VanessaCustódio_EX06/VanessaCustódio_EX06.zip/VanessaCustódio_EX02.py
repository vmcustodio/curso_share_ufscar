lista = [7,8,6,7,2,6]
cont = 0
soma = 0
while cont < len(lista):
    soma += lista[cont]
    cont+= 1
print(soma)